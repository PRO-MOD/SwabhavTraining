package com.aurionpro.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@AllArgsConstructor
@RequiredArgsConstructor
@Data
public class AddressRequestDTO {

	private String city;

	private String state;

	private String pincode;
}
