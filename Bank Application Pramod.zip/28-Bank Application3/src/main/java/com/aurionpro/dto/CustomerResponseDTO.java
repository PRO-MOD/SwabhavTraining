package com.aurionpro.dto;

import java.time.LocalDate;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@AllArgsConstructor
@RequiredArgsConstructor
@Data
public class CustomerResponseDTO {
	
	
	private int customerID;

	private String emailId;
	
	private String mobileNo;
	
	private LocalDate dob;
	
	private AddressResponseDTO address;
	
	private List<AccountResponseDTO>accounts;
	
	
	
}
