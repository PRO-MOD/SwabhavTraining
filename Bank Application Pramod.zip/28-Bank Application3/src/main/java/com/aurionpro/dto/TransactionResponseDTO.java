package com.aurionpro.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@AllArgsConstructor
@RequiredArgsConstructor
@Data
public class TransactionResponseDTO {
	
	private int transactionId;

	private String transactionType;

	private int amount;

	private LocalDateTime dateTime;

	private String destAccountNo;

	private int accountId;

	private int customerId;

}
