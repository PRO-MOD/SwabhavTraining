package com.aurionpro.dto;

import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@AllArgsConstructor
@RequiredArgsConstructor
@Data
public class UserDTO {

	private int userId;
	private String username;
	private Set<String>roles;
}
