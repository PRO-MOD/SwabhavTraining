package com.aurionpro.mapper;

import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.aurionpro.dto.AccountRequestDTO;
import com.aurionpro.dto.AccountResponseDTO;
import com.aurionpro.dto.AccountUpdateDTO;
import com.aurionpro.dto.AddressRequestDTO;
import com.aurionpro.dto.AddressResponseDTO;
import com.aurionpro.dto.AddressUpdateDTO;
import com.aurionpro.dto.CustomerRequestDTO;
import com.aurionpro.dto.CustomerResponseDTO;
import com.aurionpro.dto.CustomerUpdateDTO;
import com.aurionpro.dto.TransactionRequestDTO;
import com.aurionpro.dto.TransactionResponseDTO;
import com.aurionpro.dto.UserDTO;
import com.aurionpro.entity.Account;
import com.aurionpro.entity.Address;
import com.aurionpro.entity.Customer;
import com.aurionpro.entity.Role;
import com.aurionpro.entity.Transaction;
import com.aurionpro.entity.User;

@Service
public class MapperService {

	private final ModelMapper modelMapper;
	
	public MapperService(ModelMapper modelMapper) {
		this.modelMapper=modelMapper;
	}
	
	
	
	
	public UserDTO toUserDTO(User user) {
		
		UserDTO dto=new UserDTO();
		
		dto.setUsername(user.getUsername());
		dto.setUserId(user.getUserId());
		dto.setRoles(user.getRoles().stream().map(Role::getRoleName).collect(Collectors.toSet()));
		
		return dto;
	}
	
	
	public CustomerResponseDTO toCustomerDTO(Customer customer) {
	
		CustomerResponseDTO dto=modelMapper.map(customer,CustomerResponseDTO.class);
		
		if(customer.getAccounts()!=null) {
			dto.setAccounts(customer.getAccounts().stream().map(this::toAccountDTO).toList());
		}
		
		 if(customer.getAddress() != null) {
		        dto.setAddress(modelMapper.map(customer.getAddress(), AddressResponseDTO.class));
		    }
		return dto;
	}
	
	public Customer toCustomerEntity(CustomerRequestDTO dto) {
        return modelMapper.map(dto, Customer.class);
    }
	
	public AccountResponseDTO toAccountDTO(Account account) {
		AccountResponseDTO dto=modelMapper.map(account,AccountResponseDTO.class);
		
		if(account.getTransactions()!=null) {
			dto.setTransactions(account.getTransactions().stream().map(this::toTransactionDTO).toList());
		}
		
		return dto;
	}
	

    public Account toAccountEntity(AccountRequestDTO dto) {
        return modelMapper.map(dto, Account.class);
    }
	
	public TransactionResponseDTO toTransactionDTO(Transaction transaction) {
		  TransactionResponseDTO dto = modelMapper.map(transaction, TransactionResponseDTO.class);
		  
		  if(transaction.getAccount()!=null) {
			  dto.setAccountId(transaction.getAccount().getAccountID());
		  }
		  
		  if(transaction.getCustomer()!=null) {
			  dto.setCustomerId(transaction.getCustomer().getCustomerID());
		  }
		  
		  return dto;
	}
	
//	  public Transaction toTransactionEntity(TransactionRequestDTO requestDTO, Customer customer, Account sourceAccount, Account destAccount) {
//	        Transaction transaction = modelMapper.map(requestDTO, Transaction.class);
//
//	        // set associations manually
//	        transaction.setCustomer(customer);
//	        transaction.setAccount(sourceAccount);
//
//	        // destAccountNo is in requestDTO, but not directly in Transaction entity
//	        // you might use destAccount for transfer logic in service layer
//
//	        return transaction;
//	    }
	
	
	 public Customer toCustomerFromUpdate(CustomerUpdateDTO dto, Customer existing) {
	        
	        if (dto.getEmailId() != null) existing.setEmailId(dto.getEmailId());
	        if (dto.getMobileNo() != null) existing.setMobileNo(dto.getMobileNo());
	        return existing;
	    }
	
	 

	    public Account toAccountFromUpdate(AccountUpdateDTO dto, Account existing) {
	        if (dto.getAccountType() != null) existing.setAccountType(dto.getAccountType());
	        return existing;
	    }
	
	public AddressResponseDTO toAddressDTO(Address address) {
	    return modelMapper.map(address, AddressResponseDTO.class);
	}

	public Address toAddressEntity(AddressRequestDTO dto) {
	    return modelMapper.map(dto, Address.class);
	}
	
	public Address toAddressEntityUpadted(AddressUpdateDTO dto) {
	    return modelMapper.map(dto, Address.class);
	}


    public Transaction toTransactionEntity(TransactionRequestDTO dto) {
        return modelMapper.map(dto, Transaction.class);
    }
	
}
