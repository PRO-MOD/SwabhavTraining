package com.aurionpro.SMS;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;



@Service
public class SMSService {
	
		@Value("${twilio.account.sid}")
	    private String accountSid;

	    @Value("${twilio.auth.token}")
	    private String authToken;

	    @Value("${twilio.phone.number}")
	    private String fromPhoneNumber;

	    private boolean initialized = false;

	    private void init() {
	        if (!initialized) {
	            Twilio.init(accountSid, authToken);
	            initialized = true;
	        }
	    }

	    public void sendSms(String toPhoneNumber, String messageBody) {
	        init();
	        Message.creator(
	                new com.twilio.type.PhoneNumber(toPhoneNumber),
	                new com.twilio.type.PhoneNumber(fromPhoneNumber),
	                messageBody
	        ).create();
	        System.out.println("SMS sent to " + toPhoneNumber + ": " + messageBody);
	    }
}
