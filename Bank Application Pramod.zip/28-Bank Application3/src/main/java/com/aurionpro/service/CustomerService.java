package com.aurionpro.service;

import java.util.List;

import com.aurionpro.dto.AddressUpdateDTO;
import com.aurionpro.dto.CustomerRequestDTO;
import com.aurionpro.dto.CustomerResponseDTO;
import com.aurionpro.dto.CustomerUpdateDTO;


public interface CustomerService {

	CustomerResponseDTO createCustomer(CustomerRequestDTO customerDTO,int userId);
	
	CustomerResponseDTO getCustomerById(int id);
	
	List<CustomerResponseDTO> getAllCustomers();
	
	CustomerResponseDTO updateCustomer(int customerId, CustomerUpdateDTO dto);
	
    CustomerResponseDTO updateAddress(int customerId, AddressUpdateDTO dto);
	
	void deleteCustomer(int id);

	
}
