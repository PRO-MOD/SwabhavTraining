package com.aurionpro.service;


import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.aurionpro.Emailer.EmailService;
import com.aurionpro.SMS.SMSService;
import com.aurionpro.dto.TransactionRequestDTO;
import com.aurionpro.dto.TransactionResponseDTO;
import com.aurionpro.entity.Account;
import com.aurionpro.entity.Customer;
import com.aurionpro.entity.Transaction;
import com.aurionpro.entity.User;
import com.aurionpro.exception.BadRequestException;
import com.aurionpro.exception.ResourceNotFound;
import com.aurionpro.mapper.MapperService;
import com.aurionpro.repository.AccountRepository;
import com.aurionpro.repository.CustomerRepository;
import com.aurionpro.repository.TransactionRepository;
import com.aurionpro.repository.UserRepository;

import jakarta.transaction.Transactional;
import lombok.Data;

@Service
@Data
public class TransactionServiceImpl implements TransactionalService {

	private final TransactionRepository txnRepo;
	private final AccountRepository accountRepo;
	private final CustomerRepository customerRepo;
	private final MapperService mapper;
	private final EmailService emailService;
	private final SMSService smsService;
	private final UserRepository userRepo;


	@Override
	@Transactional
	public TransactionResponseDTO createTransaction(int accountId, TransactionRequestDTO dto) {

		Account acc = accountRepo.findById(accountId).orElseThrow(() -> new ResourceNotFound("Account not Found!"));

		Customer c = acc.getCustomer();
		
		 User user=c.getUser();

		if(dto.getAmount()<=0) {
			throw new BadRequestException("Amount must be positive");
		}

		Transaction t = mapper.toTransactionEntity(dto);
		
		t.setAccount(acc);
		t.setCustomer(c);
		
		
		    t.setDateTime(LocalDateTime.now());
		
		
		
		
		if ("debit".equalsIgnoreCase(dto.getTransactionType())) {
			if(acc.getBalance()<dto.getAmount()) {
				throw new BadRequestException("Insufficient balance");
			}

			acc.setBalance(acc.getBalance() - dto.getAmount());
		}

		else if ("credit".equalsIgnoreCase(dto.getTransactionType())) {
			acc.setBalance(acc.getBalance() + dto.getAmount());
		}

		else if ("transfer".equalsIgnoreCase(dto.getTransactionType())) {
			String destAccNo = dto.getDestAccountNo();

			if(destAccNo==null) {
				throw new BadRequestException("Destination account missing in remarks for transfer");
			}

			Account destAcc = accountRepo.findByAccountNumber(destAccNo)
					.orElseThrow(() -> new ResourceNotFound("Destination Account not Found!"));

			if(acc.getBalance()<dto.getAmount()) {
			throw new BadRequestException("Insufficient balance");
		}

			acc.setBalance(acc.getBalance() - dto.getAmount());
			destAcc.setBalance(destAcc.getBalance() + dto.getAmount());

			accountRepo.save(destAcc);

		}

		else {
			  throw new BadRequestException("Unknown transaction type");
		}

		accountRepo.save(acc);

		Transaction saved = txnRepo.save(t);
		
		String to = c.getEmailId();
		String subject = "Transaction Alert - " + saved.getTransactionType();
		String body = String.format(
		    "Dear %s,\n\n" +
		    "We wish to inform you that a %s transaction of INR %s has been successfully %s from your account %s on %s.\n\n" +
		    "Available Balance: INR %s\n\n" +
		    "If you did not authorize this transaction, please contact our customer support immediately.\n\n" +
		    "Thank you for banking with us.\n\n" +
		    "Warm regards,\n" +
		    "BankApp Support Team",
		    user.getUsername(), 
		    saved.getTransactionType(),
		    String.valueOf(saved.getAmount()),
		    saved.getTransactionType().equalsIgnoreCase("DEBIT") ? "debited" :
		        (saved.getTransactionType().equalsIgnoreCase("CREDIT") ? "credited" : "processed"),
		    acc.getAccountNumber(),
		    saved.getDateTime(),
		    String.valueOf(acc.getBalance())
		);

       
        emailService.sendSimpleEmail(to, subject, body);
        
       
        
//        smsService.sendSms(
//        	    c.getMobileNo(),
//        	    "Dear " + user.getUsername() +
//        	    ", INR " + saved.getAmount() + " " + saved.getTransactionType().toUpperCase() +
//        	    " from your " + saved.getAccount().getAccountType() +
//        	    " A/C ****" + saved.getAccount().getAccountNumber()
//        	        .substring(saved.getAccount().getAccountNumber().length() - 4) +
//        	    " on " + saved.getDateTime() +
//        	    ". Avl Bal: INR " + acc.getBalance() +
//        	    ". - AurionPro Bank"
//        	);



		return mapper.toTransactionDTO(saved);
	}

	@Override
	public List<TransactionResponseDTO> getTransactionByAccount(int accountId) {

	    Account acc = accountRepo.findById(accountId).orElseThrow(() -> new ResourceNotFound("Account not found"));
	    
	    
		return txnRepo.findByAccount(acc).stream().map(mapper::toTransactionDTO).toList();
	}

	@Override
	public List<TransactionResponseDTO> getTransactionByCustomer(int customerID) {
		
		 Customer c = customerRepo.findById(customerID).orElseThrow(() -> new ResourceNotFound("Customer not found"));
		 
		return txnRepo.findByCustomer(c).stream().map(mapper::toTransactionDTO).toList();
	}

	@Override
	public TransactionResponseDTO getTransactionById(int transactionId) {

		  return txnRepo.findById(transactionId).map(mapper::toTransactionDTO)
	                .orElseThrow(() -> new ResourceNotFound("Transaction not found"));
	}

	@Override
	public List<TransactionResponseDTO> getPassbook(Integer accountId) {
		
		Account acc=accountRepo.findById(accountId).orElseThrow(()->new ResourceNotFound("Account not Found!"));
		
		List<TransactionResponseDTO> txns=txnRepo.findByAccount(acc).stream().map(mapper::toTransactionDTO).toList();
		
		
		Customer cust = acc.getCustomer();
		String to = cust.getEmailId();
		String subject = "Passbook Accessed - Account " + acc.getAccountNumber();
		
		
//		String body = String.format(
//		    "Dear %s,\n\n" +
//		    "This is to inform you that your passbook for Account No: ****%s was accessed on %s.\n\n" +
//		    " Current Balance: INR %s\n\n" +
//		    "If this was not initiated by you, please contact our customer support immediately.\n\n" +
//		    "Regards,\nAurionPro Bank",
//		    cust.getUser().getUsername(), 
//		    acc.getAccountNumber().substring(acc.getAccountNumber().length() - 4), 
//		    java.time.format.DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm").format(java.time.LocalDateTime.now()), // nice format
//		    String.valueOf(acc.getBalance())
//		);
//
//		emailService.sendSimpleEmail(to, subject, body);
		
		
		  
	    StringBuilder table = new StringBuilder();
	    table.append("<table border='1' cellspacing='0' cellpadding='8' style='border-collapse:collapse;width:100%;font-family:Arial,sans-serif;'>");
	    table.append("<tr style='background-color:#f2f2f2;'>")
	         .append("<th>Date</th><th>Type</th><th>Amount</th><th>Balance After</th>")
	         .append("</tr>");

	    for (TransactionResponseDTO txn : txns) {
	        table.append("<tr>")
	             .append("<td>").append(txn.getDateTime()).append("</td>")
	             .append("<td>").append(txn.getTransactionType()).append("</td>")
	             .append("<td>").append("INR " + txn.getAmount()).append("</td>")
	             .append("<td>").append("INR " + acc.getBalance()).append("</td>")
	             .append("</tr>");
	    }
	    table.append("</table>");

	   
	    String htmlBody = String.format(
	        "<p>Dear <b>%s</b>,</p>" +
	        "<p>This is to inform you that your passbook for Account No: ****%s was accessed on <b>%s</b>.</p>" +
	        "<p><b>Current Balance:</b> INR %s</p>" +
	        "<h3>Recent Transactions</h3>" +
	        "%s" +  
	        "<br><p>If this was not initiated by you, please contact our customer support immediately.</p>" +
	        "<p>Regards,<br><b>AurionPro Bank</b></p>",
	        cust.getUser().getUsername(),
	        acc.getAccountNumber().substring(acc.getAccountNumber().length() - 4),
	        java.time.format.DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm").format(java.time.LocalDateTime.now()),
	        String.valueOf(acc.getBalance()),
	        table.toString()
	    );

	    emailService.sendHtmlEmail(to, subject, htmlBody);

        return txns;
		
	}

}
