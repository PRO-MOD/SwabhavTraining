package com.aurionpro.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.aurionpro.dto.AddressUpdateDTO;
import com.aurionpro.dto.CustomerRequestDTO;
import com.aurionpro.dto.CustomerResponseDTO;
import com.aurionpro.dto.CustomerUpdateDTO;
import com.aurionpro.entity.Address;
import com.aurionpro.entity.Customer;
import com.aurionpro.entity.User;
import com.aurionpro.exception.BadRequestException;
import com.aurionpro.exception.ResourceNotFound;
import com.aurionpro.mapper.MapperService;
import com.aurionpro.repository.CustomerRepository;
import com.aurionpro.repository.UserRepository;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CustomerServiceImpl implements CustomerService {

	private final CustomerRepository customerRepo;
	private final UserRepository userRepo;
	private final MapperService mapper;

	@Override
	@Transactional
	public CustomerResponseDTO createCustomer(CustomerRequestDTO dto, int userID) {

		User user = userRepo.findById(userID).orElseThrow(() -> new ResourceNotFound("User does not exits!"));

		if (user.getCustomer() != null) {
			throw new BadRequestException("User Already as customer profile!");
		}

		Customer c = mapper.toCustomerEntity(dto);
		c.setUser(user);

		if (dto.getAddress() != null) {
			c.setAddress(mapper.toAddressEntity(dto.getAddress()));
		}

		Customer saved = customerRepo.save(c);
		user.setCustomer(c);
		userRepo.save(user);

		return mapper.toCustomerDTO(c);

	}

	@Override
	public CustomerResponseDTO getCustomerById(int id) {

		return customerRepo.findById(id).map(mapper::toCustomerDTO)
				.orElseThrow(() -> new ResourceNotFound("Customer not found!"));
	}

	@Override
	public List<CustomerResponseDTO> getAllCustomers() {

		return customerRepo.findAll().stream().map(mapper::toCustomerDTO).toList();
	}

	@Override
	@Transactional
	public void deleteCustomer(int id) {
		Customer c = customerRepo.findById(id).orElseThrow(() -> new ResourceNotFound("Customer not found!"));

		User u = c.getUser();
		if (u != null) {
			u.setCustomer(null);
		}

		customerRepo.delete(c);
		customerRepo.flush();

	}

	@Override
	@Transactional
	public CustomerResponseDTO updateCustomer(int customerId, CustomerUpdateDTO dto) {
		Customer existing = customerRepo.findById(customerId)
				.orElseThrow(() -> new ResourceNotFound("Customer not found!"));
		existing = mapper.toCustomerFromUpdate(dto, existing);
		Customer saved = customerRepo.save(existing);
		return mapper.toCustomerDTO(saved);

	}

	@Override
	@Transactional
	public CustomerResponseDTO updateAddress(int customerId, AddressUpdateDTO dto) {

		Customer existing = customerRepo.findById(customerId)
				.orElseThrow(() -> new ResourceNotFound("Customer not found!"));
		Address addr = mapper.toAddressEntityUpadted(dto);
		existing.setAddress(addr);
		Customer saved = customerRepo.save(existing);
		return mapper.toCustomerDTO(saved);
	}

}
