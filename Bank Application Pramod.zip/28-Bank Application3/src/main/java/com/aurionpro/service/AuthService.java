package com.aurionpro.service;

import org.springframework.stereotype.Service;

import com.aurionpro.dto.AuthResponseDTO;
import com.aurionpro.dto.LoginDTO;
import com.aurionpro.dto.UserRegisterDTO;
import com.aurionpro.dto.RegistrationResponseDTO;


public interface AuthService {
	
	RegistrationResponseDTO register(UserRegisterDTO registrationDTO);

	String login(LoginDTO loginDTO);
	
}
