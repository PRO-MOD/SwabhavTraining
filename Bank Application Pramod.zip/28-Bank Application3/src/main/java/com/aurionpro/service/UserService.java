package com.aurionpro.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.aurionpro.dto.UserDTO;

public interface UserService {

	UserDTO	getUserById(int id);
	
	List<UserDTO>getAllUsers();
	
	void deleteUserById(int id);
}
