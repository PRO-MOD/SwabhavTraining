package com.aurionpro.service;

import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Service;

import com.aurionpro.Emailer.EmailService;
import com.aurionpro.SMS.SMSService;
import com.aurionpro.dto.AccountRequestDTO;
import com.aurionpro.dto.AccountResponseDTO;
import com.aurionpro.dto.AccountUpdateDTO;
import com.aurionpro.entity.Account;
import com.aurionpro.entity.Customer;
import com.aurionpro.entity.User;
import com.aurionpro.exception.ResourceNotFound;
import com.aurionpro.mapper.MapperService;
import com.aurionpro.repository.AccountRepository;
import com.aurionpro.repository.CustomerRepository;
import com.aurionpro.repository.UserRepository;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AccountServiceImpl implements AccountService {

	private final AccountRepository accountRepo;
	private final CustomerRepository customerRepo;
	private final MapperService mapper;
	private final EmailService emailService;
	private final SMSService smsService;
	private final UserRepository userRepo;

	private final Random random = new Random();

	@Override
	@Transactional
	public AccountResponseDTO createAccount(int id, AccountRequestDTO dto) {

		Customer c = customerRepo.findById(id).orElseThrow(() -> new ResourceNotFound("Customer not Found"));
		
		User user=c.getUser();
		

		Account acc = mapper.toAccountEntity(dto);

		acc.setAccountNumber(generateAccountNumber());

		acc.setCustomer(c);

		Account savedAccount = accountRepo.save(acc);

		emailService.sendSimpleEmail(
			    c.getEmailId(),
			    "Welcome! Your New Account Has Been Created",
			    String.format(
			        "Dear %s,\n\n" +
			        "We are pleased to inform you that your new %s account has been successfully created.\n\n" +
			        "Account No: ****%s\n" +
			        "If you have any questions or did not authorize this, please contact our customer support immediately.\n\n" +
			        "Thank you for choosing AurionPro Bank.\n\n" +
			        "Regards,\n" +
			        "AurionPro Bank",
			        c.getUser().getUsername(), 
			        acc.getAccountType(),
			        acc.getAccountNumber().substring(acc.getAccountNumber().length() - 4)
			    )
			);

		
//		smsService.sendSms(
//			    c.getMobileNo(),
//			    "Dear " + user.getUsername() + ", your " + savedAccount.getAccountType() +
//			    " account (A/C No: ****" + savedAccount.getAccountNumber().substring(savedAccount.getAccountNumber().length() - 4) + 
//			    ") has been successfully created with AurionPro Bank."
//			);



		return mapper.toAccountDTO(savedAccount);

	}

	@Override
	public String generateAccountNumber() {

		long number = (long) (Math.random() * 10000000000L);

		return String.format("%010d", number);

	}

	@Override
	public List<AccountResponseDTO> getAccountsOfCustomer(int customerId) {
		Customer c = customerRepo.findById(customerId).orElseThrow(() -> new ResourceNotFound("Customer not Found"));

		return accountRepo.findByCustomer(c).stream().map(mapper::toAccountDTO).toList();
	}

	@Override
	public List<AccountResponseDTO> getAllAccounts() {

		return accountRepo.findAll().stream().map(mapper::toAccountDTO).toList();
	}

	@Override
	public AccountResponseDTO getAccountByAccountNumber(String accountNo) {

		Account acc = accountRepo.findByAccountNumber(accountNo)
				.orElseThrow(() -> new ResourceNotFound("Account not Found"));

		return mapper.toAccountDTO(acc);
	}

	@Override
	@Transactional
	public AccountResponseDTO updateAccount(Integer accountId, AccountUpdateDTO dto) {
		Account existing = accountRepo.findById(accountId).orElseThrow(() -> new ResourceNotFound("Account not found"));

		existing = mapper.toAccountFromUpdate(dto, existing);

		Account saved = accountRepo.save(existing);

		return mapper.toAccountDTO(saved);
	}

	@Override
	@Transactional
	public void deleteAccount(int accountId) {
		Account acc = accountRepo.findById(accountId).orElseThrow(() -> new ResourceNotFound("Account does not exits"));

		Customer customer = acc.getCustomer();
		String accNo = acc.getAccountNumber();
		String accType = acc.getAccountType();
		
		User user=customer.getUser();

		accountRepo.deleteById(accountId);
		
		emailService.sendSimpleEmail(
			    customer.getEmailId(),
			    "Account Deletion Confirmation - Account " + accNo,
			    String.format(
			        "Dear %s,\n\n" +
			        "We wish to inform you that your %s account (A/C No: ****%s) has been successfully deleted from our records.\n\n" +
			        "If you did not request this action or have any questions, please contact our customer support immediately.\n\n" +
			        "Regards,\n" +
			        "AurionPro Bank",
			        customer.getUser().getUsername(), 
			        accType,
			        accNo.substring(accNo.length() - 4) 
			    )
			);

		 
		 
//		 smsService.sendSms(
//				 customer.getMobileNo(),
//				    "Dear " + user.getUsername() + ", your " + acc.getAccountType() +
//				    " account (A/C No: ****" + acc.getAccountNumber().substring(acc.getAccountNumber().length() - 4) +
//				    ") has been permanently deleted from AurionPro Bank."
//				);


	}

}
