package com.aurionpro.service;

import java.util.List;

import com.aurionpro.dto.AccountRequestDTO;
import com.aurionpro.dto.AccountResponseDTO;
import com.aurionpro.dto.AccountUpdateDTO;


public interface AccountService {

	AccountResponseDTO createAccount (int customerId,AccountRequestDTO accountDTO);
	
	String generateAccountNumber();
	
	List<AccountResponseDTO>getAccountsOfCustomer(int customerId);
	
	List<AccountResponseDTO>getAllAccounts();
	
	AccountResponseDTO getAccountByAccountNumber(String accountNo);
	
	 AccountResponseDTO updateAccount(Integer accountId, AccountUpdateDTO dto);
	
	 void deleteAccount(int accountId);
}
