package com.aurionpro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aurionpro.dto.UserDTO;
import com.aurionpro.entity.User;
import com.aurionpro.exception.ResourceNotFound;
import com.aurionpro.mapper.MapperService;
import com.aurionpro.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class UserServiceImpl implements UserService {

	private UserRepository userRepo;
	private MapperService mapper;

	@Autowired
	public UserServiceImpl(UserRepository userRepo, MapperService mapper) {
		this.userRepo = userRepo;
		this.mapper = mapper;
	}

	@Override
	public UserDTO getUserById(int id) {
		User user = userRepo.findById(id).orElseThrow(() -> new ResourceNotFound("User does not exits!"));
		UserDTO dto = mapper.toUserDTO(user);

		return dto;

	}

	@Override
	public List<UserDTO> getAllUsers() {

		return userRepo.findAll().stream().map(mapper::toUserDTO).toList();
	}

	@Override
	@Transactional
	public void deleteUserById(int id) {
		User user = userRepo.findById(id).orElseThrow(() -> new ResourceNotFound("User does not exits!"));
		userRepo.delete(user);
	}

}
