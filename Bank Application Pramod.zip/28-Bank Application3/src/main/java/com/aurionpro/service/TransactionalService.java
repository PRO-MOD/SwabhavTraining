package com.aurionpro.service;

import java.util.List;

import com.aurionpro.dto.TransactionRequestDTO;
import com.aurionpro.dto.TransactionResponseDTO;


public interface TransactionalService {

	TransactionResponseDTO createTransaction(int accountId,TransactionRequestDTO transactionDTO);
	
	List<TransactionResponseDTO> getTransactionByAccount(int accountId);
	
	List<TransactionResponseDTO> getTransactionByCustomer(int customerID);
	
	TransactionResponseDTO getTransactionById(int transactionId);
	
	  List<TransactionResponseDTO> getPassbook(Integer accountId);
}
