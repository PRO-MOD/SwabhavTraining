package com.aurionpro.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.dto.TransactionRequestDTO;
import com.aurionpro.dto.TransactionResponseDTO;
import com.aurionpro.entity.Account;
import com.aurionpro.entity.User;
import com.aurionpro.exception.BadRequestException;
import com.aurionpro.exception.ResourceNotFound;
import com.aurionpro.repository.AccountRepository;
import com.aurionpro.repository.CustomerRepository;
import com.aurionpro.repository.UserRepository;
import com.aurionpro.service.TransactionalService;

import jakarta.validation.Valid;
import lombok.Data;

@RestController
@RequestMapping("/transactions")
@Data
public class TransactionController {

	private final TransactionalService service;
	private final AccountRepository accountRepo;
	private final CustomerRepository customerRepo;
	private final UserRepository userRepo;
	
	private final CustomerRepository customerRepository;
	
	@PostMapping("/create/{accountId}")
	public ResponseEntity<TransactionResponseDTO> createTransaction(@PathVariable int accountId,
			@Valid @RequestBody TransactionRequestDTO dto,Principal principal) {
		
	User loggedInUser=userRepo.findByUsername(principal.getName()).orElseThrow(()-> new ResourceNotFound("User not found"));
	
	Account account=accountRepo.findById(accountId).orElseThrow(()->new ResourceNotFound("Account not found!"));
	
	if(account.getCustomer().getUser().getUserId()!=loggedInUser.getUserId()) {
		throw new BadRequestException("Unauthorized: You cannot perform transactions on this account");
	}
		return ResponseEntity.status(201).body(service.createTransaction(accountId, dto));
	}

	@GetMapping("/account/{accountId}")
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<List<TransactionResponseDTO>> getTransactionByAccount(@PathVariable int accountId) {
		return ResponseEntity.ok(service.getTransactionByAccount(accountId));
	}

	@GetMapping("/{transId}")
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<TransactionResponseDTO> getTransactionById(@PathVariable int transId) {
		return ResponseEntity.ok(service.getTransactionById(transId));
	}

	@GetMapping("/customer/{customerId}")
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<List<TransactionResponseDTO>> getTransactionByCustomer(@PathVariable int customerId) {
		return ResponseEntity.ok(service.getTransactionByCustomer(customerId));
	}

	@GetMapping("/passbook/{accountId}")
	public ResponseEntity<List<TransactionResponseDTO>> passbook(@PathVariable Integer accountId,Principal principal) {
		
		User loggedInUser=userRepo.findByUsername(principal.getName()).orElseThrow(()-> new ResourceNotFound("User not found"));
		
		Account account=accountRepo.findById(accountId).orElseThrow(()->new ResourceNotFound("Account not found!"));
		
		if(account.getCustomer().getUser().getUserId()!=loggedInUser.getUserId()) {
			throw new BadRequestException("Unauthorized: You cannot View other accounts passbook");
		}
		
		return ResponseEntity.ok(service.getPassbook(accountId));
	}
}
