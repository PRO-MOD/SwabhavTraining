package com.aurionpro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.dto.UserDTO;
import com.aurionpro.service.UserService;

import lombok.Data;

@RestController
@RequestMapping("/users")
@Data
public class UserController {

	@Autowired
	private UserService service;
	
	@GetMapping
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<List<UserDTO>> getAllUsers() {
		return ResponseEntity.ok(service.getAllUsers());
	}
	
	@GetMapping("/{id}")
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<UserDTO> getUserById(@PathVariable ("id") int id) {
		return ResponseEntity.ok(service.getUserById(id));
	}
	
	@DeleteMapping("/{id}")
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<Void> deleteUserById(@PathVariable ("id") int id) {
		service.deleteUserById(id);
		return ResponseEntity.noContent().build();
	}
}
