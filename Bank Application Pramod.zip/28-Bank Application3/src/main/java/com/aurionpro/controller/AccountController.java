package com.aurionpro.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.dto.AccountRequestDTO;
import com.aurionpro.dto.AccountResponseDTO;
import com.aurionpro.dto.AccountUpdateDTO;
import com.aurionpro.entity.Account;
import com.aurionpro.entity.Customer;
import com.aurionpro.entity.User;
import com.aurionpro.exception.BadRequestException;
import com.aurionpro.exception.ResourceNotFound;
import com.aurionpro.repository.AccountRepository;
import com.aurionpro.repository.CustomerRepository;
import com.aurionpro.repository.UserRepository;
import com.aurionpro.service.AccountService;

import jakarta.validation.Valid;
import lombok.Data;

@RestController
@RequestMapping("/accounts")
@Data
public class AccountController {

	private final AccountService service;

	private final AccountRepository accountRepo;
	private final CustomerRepository customerRepo;
	private final UserRepository userRepo;

	private final CustomerRepository customerRepository;

	@PostMapping("/create/{customerId}")
	public ResponseEntity<AccountResponseDTO> create(@PathVariable("customerId") int customerId,
			@Valid @RequestBody AccountRequestDTO dto, Principal principal) {

		User loggedInUser = userRepo.findByUsername(principal.getName())
				.orElseThrow(() -> new ResourceNotFound("User not found"));

		Customer customer = customerRepo.findById(customerId)
				.orElseThrow(() -> new ResourceNotFound("customer not found!"));

		if (customer.getUser().getUserId() != loggedInUser.getUserId()) {
			throw new BadRequestException("Unauthorized:You cannot create other customer's Account");
		}

		return ResponseEntity.status(201).body(service.createAccount(customerId, dto));
	}

	@GetMapping("/customer/{customerId}")
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<List<AccountResponseDTO>> getByCustomer(@PathVariable("customerId") int customerId) {
		return ResponseEntity.ok(service.getAccountsOfCustomer(customerId));
	}

	@GetMapping
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<List<AccountResponseDTO>> getAllAccounts() {
		return ResponseEntity.ok(service.getAllAccounts());
	}

	@GetMapping("/{accNo}")
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<AccountResponseDTO> getByAccountNumber(@PathVariable("accNo") String accNo) {

		return ResponseEntity.ok(service.getAccountByAccountNumber(accNo));
	}

	@PutMapping("/{accountId}")
	public ResponseEntity<AccountResponseDTO> updateAccount(@PathVariable Integer accountId,
			@RequestBody AccountUpdateDTO dto, Principal principal) {
		User loggedInUser = userRepo.findByUsername(principal.getName())
				.orElseThrow(() -> new ResourceNotFound("User not found"));

		Account account = accountRepo.findById(accountId).orElseThrow(() -> new ResourceNotFound("Account not found!"));

		if (account.getCustomer().getUser().getUserId() != loggedInUser.getUserId()) {
			throw new BadRequestException("Unauthorized:You cannot update other customer's Account");
		}

		return ResponseEntity.ok(service.updateAccount(accountId, dto));
	}

	@DeleteMapping("/{accountId}")
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<Void> deleteAccount(@PathVariable("accountId") int id, Principal principal) {

//		User loggedInUser = userRepo.findByUsername(principal.getName())
//				.orElseThrow(() -> new ResourceNotFound("User not found"));
//		Account account = accountRepo.findById(id).orElseThrow(() -> new ResourceNotFound("Account not found!"));
//
//		if (account.getCustomer().getUser().getUserId() != loggedInUser.getUserId()) {
//			throw new BadRequestException("Unauthorized:You cannot delete other customer's Account");
//		}

		service.deleteAccount(id);
		return ResponseEntity.noContent().build();
	}
}
