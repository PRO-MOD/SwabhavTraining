package com.aurionpro.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.dto.AddressUpdateDTO;
import com.aurionpro.dto.CustomerRequestDTO;
import com.aurionpro.dto.CustomerResponseDTO;
import com.aurionpro.dto.CustomerUpdateDTO;
import com.aurionpro.entity.Customer;
import com.aurionpro.entity.User;
import com.aurionpro.exception.BadRequestException;
import com.aurionpro.exception.ResourceNotFound;
import com.aurionpro.repository.AccountRepository;
import com.aurionpro.repository.CustomerRepository;
import com.aurionpro.repository.UserRepository;
import com.aurionpro.service.CustomerService;

import lombok.Data;

@RestController
@RequestMapping("/customers")
@Data
public class CustomerController {

	private final CustomerService service;
	
	private final AccountRepository accountRepo;
	private final CustomerRepository customerRepo;
	private final UserRepository userRepo;
	
	private final CustomerRepository customerRepository;

	@PostMapping("/create/{userId}")
	public ResponseEntity<CustomerResponseDTO> createCustomer(@PathVariable("userId") int id,
			@RequestBody CustomerRequestDTO dto,Principal principal) {
		User loggedInCustomer = userRepo.findByUsername(principal.getName())
				.orElseThrow(() -> new ResourceNotFound("User not found"));


		if (id != loggedInCustomer.getUserId()) {
			throw new BadRequestException("Unauthorized:You cannot create other users profile");
		}

		return ResponseEntity.status(201).body(service.createCustomer(dto, id));
	}

	@GetMapping("/{customerId}")
	@PreAuthorize("hasRole('Admin')")
	@PreAuthorize("hasRole('Customer')")
	public ResponseEntity<CustomerResponseDTO> getCustomerById(@PathVariable("customerId") int id,Principal principal) {
		User loggedInCustomer = userRepo.findByUsername(principal.getName())
				.orElseThrow(() -> new ResourceNotFound("User not found"));

		Customer customer = customerRepo.findById(id).orElseThrow(() -> new ResourceNotFound("customer not found!"));

		if (customer.getUser().getUserId() != loggedInCustomer.getUserId()) {
			throw new BadRequestException("Unauthorized:You cannot update other users profile");
		}
		
		
		return ResponseEntity.ok(service.getCustomerById(id));
	}

	@GetMapping
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<List<CustomerResponseDTO>> getAllCustomers() {
		return ResponseEntity.ok(service.getAllCustomers());
	}

	@PutMapping("/{id}")
	public ResponseEntity<CustomerResponseDTO> updateCustomer(@PathVariable int id,
			@RequestBody CustomerUpdateDTO dto,Principal principal) {
		
		User loggedInCustomer = userRepo.findByUsername(principal.getName())
				.orElseThrow(() -> new ResourceNotFound("User not found"));

		Customer customer = customerRepo.findById(id).orElseThrow(() -> new ResourceNotFound("customer not found!"));

		if (customer.getUser().getUserId() != loggedInCustomer.getUserId()) {
			throw new BadRequestException("Unauthorized:You cannot update other users profile");
		}
		
		return ResponseEntity.ok(service.updateCustomer(id, dto));
	}

	@PutMapping("/{id}/address")
	public ResponseEntity<CustomerResponseDTO> updateAddress(@PathVariable int id, @RequestBody AddressUpdateDTO dto,Principal principal) {
		
		User loggedInCustomer = userRepo.findByUsername(principal.getName())
				.orElseThrow(() -> new ResourceNotFound("User not found"));

		Customer customer = customerRepo.findById(id).orElseThrow(() -> new ResourceNotFound("customer not found!"));

		if (customer.getUser().getUserId() != loggedInCustomer.getUserId()) {
			throw new BadRequestException("Unauthorized:You cannot update other users address");
		}
		
		return ResponseEntity.ok(service.updateAddress(id, dto));
		
		
		
	}
	@PreAuthorize("hasRole('Admin')")
	@DeleteMapping("/{customerId}")
	public ResponseEntity<Void> deleteCustomer(@PathVariable("customerId") int id) {
		service.deleteCustomer(id);
		return ResponseEntity.noContent().build();
	}

}
