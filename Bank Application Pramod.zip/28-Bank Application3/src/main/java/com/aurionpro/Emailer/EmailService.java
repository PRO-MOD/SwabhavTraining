package com.aurionpro.Emailer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

	private final JavaMailSender mailSender;

	private final String from;

	public EmailService(JavaMailSender mailSender, @Value("${app.email.from}") String from) {
		this.mailSender = mailSender;
		this.from = from;
	}

	public void sendSimpleEmail(String to,String subject,String text) {
		try {
			SimpleMailMessage msg=new SimpleMailMessage();
			msg.setFrom(from);
			msg.setTo(to);
			msg.setSubject(subject);
			msg.setText(text);
			
			mailSender.send(msg);
		}
		catch(Exception e) {
			System.err.println("Failed to send Email:"+e.getMessage());
		}
	}
	
	
	public void sendHtmlEmail(String to, String subject, String htmlContent) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(from);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(htmlContent, true); 

            mailSender.send(message);
        } catch (Exception e) {
            System.err.println("Failed to send HTML Email: " + e.getMessage());
        }
    }
	
}
