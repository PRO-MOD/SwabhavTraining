package com.aurionpro.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.aurionpro.entity.Account;
import com.aurionpro.entity.Customer;
import com.aurionpro.entity.Transaction;

@Repository
public interface TransactionRepository  extends JpaRepository<Transaction, Integer>{

	List<Transaction>findByAccount(Account account);
	
	List<Transaction>findByCustomer(Customer customer);
}
