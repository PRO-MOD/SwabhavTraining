package com.aurionpro.entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@RequiredArgsConstructor
@AllArgsConstructor
@Data
@Table(name="customers")
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="customer_id")
	private int customerID;
	
	@Email
	@Column(unique = true,nullable = false)
	private String emailId;
	
	@Pattern(
		    regexp = "^\\+91[6-9][0-9]{9}$",
		    message = "Mobile number must start with +91 and be a valid 10-digit Indian number"
		)
	@Column(unique = true,nullable = false)
	private String mobileNo;
	
	@Past
	private LocalDate dob;
	
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY,optional = true)
	@JoinColumn(name="address_id", referencedColumnName = "addressId",unique = true,nullable = true)
	private Address address;
	
	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, fetch = FetchType.LAZY,orphanRemoval = true)
	private List<Account> accounts;
	
	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, fetch = FetchType.LAZY,orphanRemoval = true)
	private List<Transaction> transactions;

	
	
	@OneToOne
    @JoinColumn(name = "user_id", unique = true,nullable = false)
    private User user;

}


